let len = prompt('Введите длину комнаты');
let widht = prompt('Введите ширину комнаты');
let s;
s = len*widht;
document.write('Площадь комнаты' , s);