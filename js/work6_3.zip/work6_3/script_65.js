let year = prompt('Введите год')
if (year % 4 === 0) {
   console.log("Високосный")
} else if (year % 4 === 1) {
   console.log("Не високосный")
} else {
   console.log('Вы ничего не ввели')
}
