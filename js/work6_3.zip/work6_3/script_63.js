let x = 4;
let y = 3 + (x *= 3);
alert(`${y}`)