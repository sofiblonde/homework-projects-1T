let x = 1
let y = 1
let a = ++x; 
let b = y++; 
alert(`${a} , ${b}`);
