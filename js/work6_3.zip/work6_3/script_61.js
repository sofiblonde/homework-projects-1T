let squareData = +prompt('Введите значение стороны квадрата')
alert(`Периметр квадрата равен ${squareData * 4}. Площадь квадрата равна ${squareData * 2}`)