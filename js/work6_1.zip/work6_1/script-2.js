let a=prompt('Введите  первое число ');
let b=prompt('Введите второе число'); 
let c;
c = a*b;
alert(+(a)+'*'+(b)+'='+(c));