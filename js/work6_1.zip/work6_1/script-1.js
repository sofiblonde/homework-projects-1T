alert("Привет, Мир!");

let num = prompt('Введите число: ')

console.log(`Следующее число   ${Number(num) + 1}`)
console.log(`Предыдущее число   ${Number(num) - 1}`)

let a=prompt('Введите  первое число ');
let b=prompt('Введите второе число'); 
let c;
c = a*b;
alert(+(a)+'*'+(b)+'='+(c));