

let month = +prompt("Введите номер месяца")
function season(month) {
    if ( [1, 2, 12].includes(month)) return 'Зима'
    else if ([3, 4, 5].includes(month)) return 'Весна'
    else if ([6, 7, 8].includes(month)) return 'Лето'
    else if ([9, 10, 11].includes(month)) return 'Осень'
    else return 'Нет такого сезона'
 }
 console.log(season)
 