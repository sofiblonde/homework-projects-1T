
let  age = +prompt("Ваш возраст")
function isAdult(age){
    return age > 14
    
 }
 if (age>=14) {
    console.log(true)
 }
 else {
    console.log(false)
 }