let letter=prompt('Введите слово')
let string=prompt('Введите символ')

function count(string, letter) {
    let total = 0
    for (let i = 0; i < string.length; i++) {
        if (string[i] === letter)
            ++total
    }
    return total
    
 }
