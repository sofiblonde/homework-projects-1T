function sortNumbers(max) {
    let obj = {
        evenNums: [],
        oddNums: []
    }
    for (let i = 1; i <= max; i++) {
        obj[i % 2 ? 'oddNums' : 'evenNums'].push(i)
    }
    return obj
 }
 function sortNumbers(max) {
    let obj = {
        evenNums: [],
        oddNums: []
    }
 
    for (let counter = 1; ; counter += 2) {
        obj.evenNums.push(counter)
 
        if (counter + 1 < max) {
            obj.oddNums.push(counter + 1)
        } else {
            break
        }
    }
 
    return obj
 }
  