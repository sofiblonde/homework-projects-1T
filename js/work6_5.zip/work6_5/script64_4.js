let usersStr = 'Вася, Петя, Надя, Даша, Аня'
let users = usersStr.split(', ')